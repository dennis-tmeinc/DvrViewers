//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SimpleBrowserDemo.rc
//
#define IDR_MAINFRAME                   100
#define IDD_DIALOG                      101
#define IDC_STRING                      102
#define IDC_BROWSER_TITLE               103
#define IDC_BROWSER                     104
#define IDC_EVENTS                      105
#define IDC_URL_NAVIGATE                106
#define IDC_ANSI_RESOURCE_NAVIGATE      107
#define IDC_UNICODE_RESOURCE_NAVIGATE   108
#define IDC_WRITE                       109
#define IDC_CLEAR                       110
#define IDC_PRINT                       111
#define IDC_PRINT_HEADER                112
#define IDC_PRINT_FOOTER                113
#define IDC_CLEAR_EVENTS_NOTIFICATIONS  114
#define IDC_NOTIFICATIONS               115
#define IDC_PRINT2                      116
#define IDC_PRINT_PREVIEW               116
#define IDR_HTML_ANSI                   200
#define IDR_HTML_UNICODE                201
#define IDB_BITMAP                      300

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        401
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         400
#define _APS_NEXT_SYMED_VALUE           400
#endif
#endif
