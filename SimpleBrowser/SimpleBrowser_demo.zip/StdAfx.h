/////////////////////////////////////////////////////////////////////////////
// stdafx.h: Precompiled headers
/////////////////////////////////////////////////////////////////////////////

#if !defined(StdAfx_defined)
#define StdAfx_defined

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define UNICODE

#if defined(UNICODE)
#undef  _MBCS
#define _UNICODE
#if (!defined(_WINDLL))
#pragma comment(linker,"/entry:\"wWinMainCRTStartup\"")
#endif
#endif

#include "tchar.h"

#define VC_EXTRALEAN

#include <afxwin.h>
#include <afxext.h>
#include <afxdisp.h>
#include <afxdtctl.h>
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>
#endif

#endif // !defined(StdAfx_defined)
